#pragma once

#include<memory>
#include <shared_mutex>
#include <unordered_set>
#include <unordered_map>

#include "IStorage.h"

class MemoryStorage : public IStorage
{
public:
	MemoryStorage() = default;
	~MemoryStorage() = default;

	StorageReadWriteResult AddUser(const std::string& userName) override;
	std::pair<StorageReadWriteResult, std::vector<MsgType>> GetAllMessagesForAnUser(
		const std::string& receiver) override;
	StorageReadWriteResult AddMessage(
		const std::string& sender,
		const std::string& receiver,
		const std::string& message) override;

private:
	bool ExistsInUserTable(const std::string& userName) 
	{
		return m_users.find(userName) != m_users.end();
	}
	bool ExistsInMessageTable(const std::string& userName)
	{
		return m_messages.find(userName) != m_messages.end();
	}

	std::unordered_set<std::string> m_users;
	std::unordered_map<std::string, std::vector<std::unique_ptr<MsgType>>> m_messages;
	
	mutable std::shared_mutex m_mutex;
};