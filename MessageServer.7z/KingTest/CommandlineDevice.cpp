#include "CommandlineDevice.h"

#ifdef _WIN32
#include <conio.h>
#else
#endif

#include "Utils.h"

CommandLineDevice::CommandLineDevice(std::ostream& os, std::istream& is)
	: m_os(os)
	, m_is(is)
{}

void CommandLineDevice::ShowOptions() const
{
	ClearScreen();

	ShowMessage("Please select an option:");
	ShowMessage("1. Create User");
	ShowMessage("2. Send Message");
	ShowMessage("3. Receive All Messages For User");
	ShowMessage("4. Quit");
	ShowMessage("");
}

std::string CommandLineDevice::GetInput() const
{
	std::string input;
	std::getline(m_is, input);
	Utils::TrimString(input);
	return input;
}

void CommandLineDevice::ShowMessage(const std::string& message) const
{
	std::lock_guard<std::mutex> lock(m_mutex);
	m_os << message << std::endl;
}

char CommandLineDevice::GetSingleCharInput() const
{
	return GetInputFromKeyBoard();
}

char CommandLineDevice::GetInputFromKeyBoard() const
{
	char input = ' ';
#ifdef _WIN32
	input = _getch();
#else
	// For Linux , MacOs, etc
#endif
	return input;
}

void CommandLineDevice::ClearScreen() const
{
#ifdef _WIN32
	std::system("cls");
#elif LINUX
	std::system("clear");
#else
	// for MacOs and other devices
#endif
}
