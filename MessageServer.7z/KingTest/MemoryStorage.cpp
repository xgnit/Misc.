#include "MemoryStorage.h"

IStorage::StorageReadWriteResult MemoryStorage::AddUser(const std::string& userName)
{
    std::unique_lock<std::shared_mutex> g(m_mutex);

    bool res { false };
    std::string logMsg;

    if (userName.empty())
    {
        logMsg += "ERROR: User name cannot be empty!";
        res = false;
    }
    else if (ExistsInUserTable(userName))
    {
        logMsg += "ERROR: User '" + userName + "' already exists!";
        res = false;
    }
    else
    {
        m_users.insert(userName);
        logMsg += "User '" + userName + "' added!";
        res = true;
    }

    return { res, logMsg };
}

std::pair<IStorage::StorageReadWriteResult, std::vector<IStorage::MsgType>> 
MemoryStorage::GetAllMessagesForAnUser(const std::string& receiver)
{
    std::shared_lock<std::shared_mutex> g(m_mutex);

    const bool receiverExistsInUserTable{ ExistsInUserTable(receiver) };
    const bool receiverExistsInMessageTable{ ExistsInMessageTable(receiver) };
    
    bool res{ false };
    std::string logMsg;
    std::vector<MsgType> msgTypeVec;

    if (!receiverExistsInUserTable || !receiverExistsInMessageTable)
    {
        logMsg += receiverExistsInUserTable ? "" : "User '" + receiver + "' does not exists!";
        if (receiverExistsInUserTable)
        {
            logMsg += receiverExistsInMessageTable ? "" : "User '" + receiver + "' did not receiver any message!";
        }
        res = false;
    }
    else
    {
        res = true;
	    for (const auto& msg : m_messages.at(receiver))
	    {
            msgTypeVec.emplace_back(MsgType{ msg->first , msg->second });
	    }
    }
    return {{res, logMsg}, msgTypeVec};
}

IStorage::StorageReadWriteResult MemoryStorage::AddMessage(
    const std::string& sender,
    const std::string& receiver,
    const std::string& message)
{
    std::unique_lock<std::shared_mutex> g(m_mutex);

    const bool senderExists{ ExistsInUserTable(sender) };
    const bool receiverExists{ ExistsInUserTable(receiver) };

    bool res{ false };
    std::string logMessage;
    if (sender.empty() || receiver.empty() || message.empty())
    {
        logMessage += "ERROR: ";
        logMessage += sender.empty() ? "sender name cannot be empty!" : "";
        logMessage += receiver.empty() ? "receiver name cannot be empty!" : "";
        logMessage += message.empty() ? "message content cannot be empty!" : "";
        res = false;
    }
    else if (!senderExists || !receiverExists)
    {
        logMessage += "ERROR: ";
        logMessage += senderExists ? "" : "sender: '" + sender + "' does not exists! ";
        logMessage += receiverExists ? "" : "receiver: '" + receiver + "' does not exists! ";
        res = false;
    }
    else
    {
        if (!ExistsInMessageTable(receiver))
        {
            m_messages[receiver] = std::vector<std::unique_ptr<MsgType>>();
        }
        MsgType type{ sender, message };
        m_messages[receiver].emplace_back(std::make_unique<MsgType>(type));
        logMessage += "Message Sent!";
        res = true;
    }
    return { res, logMessage };
}