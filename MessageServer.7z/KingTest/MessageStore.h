#pragma once
#include <iostream>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "CommandlineDevice.h"
#include "MemoryStorage.h"

class MessageStore
{
public:
	explicit MessageStore(
		std::unique_ptr<IStorage> storagePtr = std::make_unique<MemoryStorage>(),
		std::unique_ptr<IDevice> devicePtr = std::make_unique<CommandLineDevice>());
	~MessageStore() = default;

	void Run();

private:
	void AddUser();
	IStorage::StorageReadWriteResult AddUserToStorage(const std::string& userName) const;
	void AddMessage();
	void AddMessageToStorage(
		const std::string& sender,
		const std::string& receiver,
		const std::string& message) const;
	void ShowMessage(const std::string& logMessage) const;
	void ShowOptions();
	void ProcessOptionInput(char input);
	std::string GetInput() const;
	void GetAllMessagesForAnUser() const;
	std::pair<IStorage::StorageReadWriteResult, std::vector<IStorage::MsgType>>
	GetAllMessagesForAnUserFromStorage(const std::string& receiver) const;
	void Finish();
	
	std::atomic<bool> m_terminate{ false };
	std::unique_ptr<IStorage> m_storage;
	std::unique_ptr<IDevice> m_device;
};