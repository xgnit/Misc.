#pragma once

#include <iostream>
#include <shared_mutex>

#include "IDevice.h"

class CommandLineDevice : public IDevice
{
public:
	CommandLineDevice(
		std::ostream& os = std::cout,
		std::istream& is = std::cin);
	~CommandLineDevice() = default;

	void ShowOptions() const override;
	std::string GetInput() const override;
	void ShowMessage(const std::string& message) const override;
	char GetSingleCharInput() const;

private:
	char GetInputFromKeyBoard() const;
	void ClearScreen() const;

	std::ostream& m_os;
	std::istream& m_is;

	mutable std::mutex m_mutex;
};