#include "MessageStore.h"

MessageStore::MessageStore(
	std::unique_ptr<IStorage> storagePtr,
	std::unique_ptr<IDevice> devicePtr)
	: m_storage(std::move(storagePtr))
	, m_device(std::move(devicePtr))
{}

void MessageStore::Run() 
{
	while (1)
	{
		m_device->ShowOptions();

		const char input = m_device->GetSingleCharInput();
		ProcessOptionInput(input);

		if (m_terminate.load())
		{
			Finish();
			m_device->GetSingleCharInput();
			return;
		}

		m_device->ShowMessage("Press any key to continue.....");		
		m_device->GetSingleCharInput();
	}
}

void MessageStore::AddUser()
{
	ShowMessage("Please enter name: ");
	std::string userName = GetInput();
	const auto res = AddUserToStorage(userName);
	ShowMessage("");
	ShowMessage(res.logMessage);
}

void MessageStore::AddMessage()
{
	ShowMessage("From: ");
	std::string sender = GetInput();
	ShowMessage("To: ");
	std::string receiver = GetInput();
	ShowMessage("Message: ");
	std::string message = GetInput();
	ShowMessage("");
	
	auto addResult = m_storage->AddMessage(sender, receiver, message);
	ShowMessage(addResult.logMessage);
}

void MessageStore::ShowMessage(const std::string& logMessage) const
{
	m_device->ShowMessage(logMessage);
}

void MessageStore::ShowOptions()
{
	ShowMessage("Please select an option:");
	ShowMessage("1. Create User");
	ShowMessage("2. Send Message");
	ShowMessage("3. Receive All Messages For User");
	ShowMessage("4. Quit");
	ShowMessage("");
}

void MessageStore::ProcessOptionInput(char input)
{
	if (!isdigit(input))
	{
		ShowMessage("Invalid Option Selected!");
	}
	else
	{
		switch (input)
		{
		case '1':
			AddUser();
			break;
		case '2':
			AddMessage();
			break;
		case '3':
			GetAllMessagesForAnUser();
			break;
		case '4':
			ShowMessage("Quitting");
			m_terminate.store(true);
			break;
		default:
			ShowMessage("Invalid Option Selected!");
			break;
		}
	}
}

std::string MessageStore::GetInput() const
{
	return m_device->GetInput();
}

void MessageStore::GetAllMessagesForAnUser() const
{
	ShowMessage("Enter a name to check this user's mail box: ");

	std::string userName = GetInput();

	auto res = GetAllMessagesForAnUserFromStorage(userName);

	const auto& storageRes = res.first;
	if (storageRes.result)
	{
		ShowMessage("===== BEGIN MESSAGES =====");
		ShowMessage("");
		int cnt = 1;
		for (const auto& msg : res.second)
		{
			ShowMessage("Message " + std::to_string(cnt));
			ShowMessage("From " + msg.first);
			ShowMessage("Content: " + msg.second);
			ShowMessage("");
			++cnt;
		}
		ShowMessage("===== END MESSAGES =====");
	}
	else
	{
		ShowMessage(storageRes.logMessage);
	}
}

void MessageStore::Finish()
{
	ShowMessage("The program ends");
	ShowMessage("Press any key to finish.....");
}

IStorage::StorageReadWriteResult MessageStore::AddUserToStorage(const std::string& userName) const
{
	return m_storage->AddUser(userName);
}

void MessageStore::AddMessageToStorage(
	const std::string& sender,
	const std::string& receiver,
	const std::string& message) const
{
	m_storage->AddMessage(sender, receiver, message);
}

std::pair<IStorage::StorageReadWriteResult, std::vector<IStorage::MsgType>>
MessageStore::GetAllMessagesForAnUserFromStorage(const std::string& receiver) const
{
	return m_storage->GetAllMessagesForAnUser(receiver);
};