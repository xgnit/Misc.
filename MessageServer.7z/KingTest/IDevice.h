#pragma once

#include<string>

class IDevice
{
public:
	virtual void ShowOptions() const = 0;
	virtual void ShowMessage(const std::string& message) const = 0;
	virtual std::string GetInput() const = 0;
	virtual char GetSingleCharInput() const = 0;
};