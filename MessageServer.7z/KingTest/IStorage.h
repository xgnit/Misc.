#pragma once

class IStorage
{
public:
	// first key is the sender, second key is the message content
	using MsgType = std::pair<std::string, std::string>;
	struct StorageReadWriteResult
	{
		bool result{ false };
		std::string logMessage;
	};

	virtual StorageReadWriteResult AddUser(const std::string& userName) = 0;
	virtual std::pair<StorageReadWriteResult, std::vector<MsgType>> GetAllMessagesForAnUser(
		const std::string& receiver) = 0;
	virtual StorageReadWriteResult AddMessage(
		const std::string& sender,
		const std::string& receiver,
		const std::string& message) = 0;
};