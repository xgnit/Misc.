#include "MessageStore.h"

int main(int, const char* [])
{
	MessageStore store;	
	store.Run();
	
	return 0;
}
